<?php

namespace Backend\Controllers;

class LoginController extends \Phalcon\Mvc\Controller
{

	public function indexAction()
	{

	}

}