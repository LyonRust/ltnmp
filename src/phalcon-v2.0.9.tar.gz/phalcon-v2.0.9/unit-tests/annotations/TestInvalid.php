<?php

/**
 * @Invalid(
 */
class TestInvalid
{

}