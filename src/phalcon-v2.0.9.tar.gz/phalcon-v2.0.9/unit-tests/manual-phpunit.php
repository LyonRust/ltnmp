<?php

define('PHPUnit_MAIN_METHOD', 'PHPUnit_TextUI_Command::main');

require 'PHPUnit'.DIRECTORY_SEPARATOR.'Autoload.php';

PHPUnit_TextUI_Command::main();
