<?php

namespace Bookshelf;

use Phalcon\Mvc\Collection;

class Books extends Collection {}