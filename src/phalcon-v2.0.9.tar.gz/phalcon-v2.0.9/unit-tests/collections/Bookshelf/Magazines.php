<?php

namespace Bookshelf;

use Phalcon\Mvc\Collection;

class Magazines extends Collection {}