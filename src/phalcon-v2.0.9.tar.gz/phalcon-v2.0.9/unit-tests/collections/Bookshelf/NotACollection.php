<?php

namespace Bookshelf;

class NotACollection {}