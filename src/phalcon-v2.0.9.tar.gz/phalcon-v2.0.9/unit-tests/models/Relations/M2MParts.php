<?php

class M2MParts extends Phalcon\Mvc\Model
{
	public function getSource()
	{
		return 'm2m_parts';
	}
}
