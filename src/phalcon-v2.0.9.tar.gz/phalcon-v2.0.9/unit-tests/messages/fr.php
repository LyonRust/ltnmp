<?php

$messages = array(
	'hi' => 'Bonjour',
	'bye' => 'Au revoir',
	'hello-key' => 'Bonjour %name%',
	'song-key' => 'La chanson est %name%, %song%'
);