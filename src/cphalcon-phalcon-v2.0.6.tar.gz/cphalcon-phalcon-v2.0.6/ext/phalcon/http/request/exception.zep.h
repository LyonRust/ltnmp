
extern zend_class_entry *phalcon_http_request_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Http_Request_Exception);

