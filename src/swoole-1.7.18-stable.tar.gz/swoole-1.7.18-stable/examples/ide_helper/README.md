Swoole IDE helper
===
```
git clone https://github.com/EagleWu/swoole-auto-complete
```
