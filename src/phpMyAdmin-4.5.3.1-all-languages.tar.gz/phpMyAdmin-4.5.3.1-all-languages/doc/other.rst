Other sources of information
============================

Printed Book
------------

The definitive guide to using phpMyAdmin is the book Mastering phpMyAdmin for
Effective MySQL Management by Marc Delisle. You can get information on that
book and other officially endorsed `books at the phpMyAdmin site`_.

.. _books at the phpMyAdmin site: https://www.phpmyadmin.net/docs/

Tutorials
---------

Third party tutorials and articles are listed on our `wiki page`_.

.. _wiki page: http://wiki.phpmyadmin.net/pma/Articles
