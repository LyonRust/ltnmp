<?php

$messages = array(
	'hi' => 'Hola',
	'bye' => 'Adiós',
	'hello-key' => 'Hola %name%',
	'song-key' => 'La canción es %name%, %song%'
);