<?php

$messages = array(
	'hi' => 'Hello',
	'bye' => 'Good Bye',
	'hello-key' => 'Hello %name%',
	'song-key' => 'This song is %name%, %song%'
);