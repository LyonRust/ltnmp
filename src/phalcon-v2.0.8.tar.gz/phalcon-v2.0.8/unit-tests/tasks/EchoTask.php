<?php

class EchoTask extends \Phalcon\CLI\Task
{

    public function mainAction()
    {
        return "echoMainAction";
    }

}
