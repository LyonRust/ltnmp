<?php

class Songs extends Phalcon\Mvc\Collection
{

}