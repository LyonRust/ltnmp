<?php if ($some_eval) { ?>
Clearly, the song is: <?php echo $this->getContent(); ?>.
<?php } ?>