#include "php.h"

zend_uchar xc_get_op_type_count();
const char *xc_get_op_type(zend_uchar op_type);
zend_uchar xc_get_data_type_count();
const char *xc_get_data_type(zend_uchar data_type);
zend_uchar xc_get_opcode_count();
const char *xc_get_opcode(zend_uchar opcode);
