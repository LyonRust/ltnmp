#ifndef XC_CACHER_H_1CADCD7E46ABC70014D0766CE97B9741
#define XC_CACHER_H_1CADCD7E46ABC70014D0766CE97B9741

#if _MSC_VER > 1000
#pragma once
#endif /* _MSC_VER > 1000 */

int xc_cacher_startup_module();
void xc_cacher_disable();

#endif /* XC_CACHER_H_1CADCD7E46ABC70014D0766CE97B9741 */
