<h2><?php echo _T("Module Info"); ?></h2>
<div class="phpinfo"><?php echo getModuleInfo(); ?></div>
