</div>
<div id="footer">
	<a href="http://validator.w3.org/check?uri=referer">
		<img src="http://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Transitional" height="31" width="88" />
	</a>
	<a href="http://jigsaw.w3.org/css-validator/check/referer">
		<img style="border:0;width:88px;height:31px" src="http://jigsaw.w3.org/css-validator/images/vcss" alt="Valid CSS!" />
	</a>
	<div id="poweredBy">
		<h3>PHP <?php
	echo phpversion();
?> Powered By: XCache <?php
	echo defined('XCACHE_VERSION') ? XCACHE_VERSION : '';
?>, <?php
	echo defined('XCACHE_MODULES') ? XCACHE_MODULES : '';
?>
		</h3>
	</div>
</div>

</body>
</html>
