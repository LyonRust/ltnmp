<?php
// auto generated, do not modify
$strings += array(
		"Document"
		=> "幫助文檔",
		"INI Reference"
		=> "INI 參考",
		"Get Support"
		=> "獲取支持",
		"Discusson"
		=> "討論",
		"Cacher"
		=> "快取器",
		"Coverager"
		=> "代码覆盖查看器",
		"Diagnosis"
		=> "診斷",
		);

