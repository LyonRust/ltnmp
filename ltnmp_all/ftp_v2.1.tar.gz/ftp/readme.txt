'User manager for PureFTPd' is made by M.Mastenbroek 2002 - 2005
For more info look at http://machiel.generaal.net
Version 2.1

Installation:

Run the installation wizard install.php in your web browser.

The installation wizard will lead you step by step 
through the configuration of the User manager for PureFTPd.

Running:

The User manager for PureFTPd starts from the index.php file.
